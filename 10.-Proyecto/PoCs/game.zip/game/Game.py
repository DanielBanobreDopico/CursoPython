from Playground import Playground
from Character import Character
from Keyboard import Keyboard

from expansions.daniel.Character import Daniel

board = Playground(5,5)
keyboard = Keyboard()
character_callbacks = [
    ("up","up"),
    ("right","right"),
    ("down","down"),
    ("left","left"),
]
character_callbacks1 = [
    ("w","up"),
    ("d","right"),
    ("s","down"),
    ("a","left"),
]
character = Character(board,keyboard,character_callbacks)
yo = Daniel(board,keyboard,character_callbacks1)
keyboard.key_capture_loop()