from  Character import Character

class Daniel(Character):
    pass
