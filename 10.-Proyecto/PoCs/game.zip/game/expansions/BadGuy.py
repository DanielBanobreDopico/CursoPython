'''
Proporcioina un objeto BadGuy que hereda de Character y supone un contrincante al que enfrentarse.
'''

from Character import Character

class BadGuy(Character):
    def __init__(self):
        super.__init__()
    '''
    Personaje autónomo para jugar contra el ordenador
    '''
    pass