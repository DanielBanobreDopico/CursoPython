'''
Proporcionar un lugar en el que añadir nuevos elementos al juego.
'''